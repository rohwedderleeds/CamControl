#include "wx_pch.h"
#include "Camera.h"
#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>

#ifndef WX_PRECOMP
	//(*InternalHeadersPCH(Camera)
	#include <wx/intl.h>
	#include <wx/string.h>
	//*)
#endif
//(*InternalHeaders(Camera)
//*)

//(*IdInit(Camera)
//*)


BEGIN_EVENT_TABLE(Camera,wxFrame)
	//(*EventTable(Camera)
	//*)
END_EVENT_TABLE()

Camera::Camera(wxWindow* parent,wxWindowID id,const wxPoint& pos,const wxSize& size)
{

	//(*Initialize(Camera)
	Create(parent, id, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("id"));
	SetClientSize(wxDefaultSize);
	Move(wxDefaultPosition);
	//*)
}

Camera::~Camera()
{
	//(*Destroy(Camera)
	//*);
}


//void Camera::OnClose(wxCloseEvent& event)
//{
//    Close();
//}
