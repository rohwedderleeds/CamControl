/***************************************************************
 * Name:      CamControlApp.h
 * Purpose:   Defines Application Class
 * Author:    Arndt Rohwedder (arndt.rohwedder@rad.uni-kiel.de)
 * Created:   2013-04-23
 * Copyright: Arndt Rohwedder ()
 * License:
 **************************************************************/

#ifndef CAMCONTROLAPP_H
#define CAMCONTROLAPP_H

#include <wx/app.h>

class CamControlApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // CAMCONTROLAPP_H
