#ifndef CAMERA_H
#define CAMERA_H

#ifndef WX_PRECOMP
	//(*HeadersPCH(Camera)
	#include <wx/frame.h>
	//*)
#endif
//(*Headers(Camera)
//*)

class Camera: public wxFrame
{
	public:

		Camera(wxWindow* parent,wxWindowID id=wxID_ANY,const wxPoint& pos=wxDefaultPosition,const wxSize& size=wxDefaultSize);
		virtual ~Camera();

		//(*Declarations(Camera)
		//*)

	protected:

		//(*Identifiers(Camera)
		//*)

	private:

		//(*Handlers(Camera)
		void OnClose(wxCloseEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
