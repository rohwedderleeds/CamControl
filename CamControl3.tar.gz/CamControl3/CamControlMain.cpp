/***************************************************************
 * Name:      CamControlMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Arndt Rohwedder (arndt.rohwedder@rad.uni-kiel.de)
 * Created:   2013-04-23
 * Copyright: Arndt Rohwedder ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "CamControlMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(CamControlFrame)
#include <wx/bitmap.h>
#include <wx/icon.h>
#include <wx/intl.h>
#include <wx/image.h>
#include <wx/string.h>
//*)

#include <libv4l2.h>
#include <linux/videodev2.h>
#include <sys/ioctl.h>

#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>

#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <assert.h>
#include <time.h>
#include <sstream>
#include <stdlib.h>

using namespace cv;
using namespace std;

//global variables (needed for all functions and should not be changed by frame functions)

double bright01 = 50;
double contrast01 = 50;
double bright02 = 50;
double contrast02 = 50;
double bright03 = 50;
double contrast03 =50;
bool crossesbutton1 = false;
bool crossesbutton2 = false;
bool crossesbutton3 = false;
bool M4boxbutton = false;
bool M8boxbutton = false;
bool M16boxbutton = false;

//frames allways needed
Mat fullscreen;
Mat singlescreen;
Mat Overlaysmall;
Mat Overlaysmall2;
Mat Overlaysmall3;

int key, pixval, fd;

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(CamControlFrame)
const long CamControlFrame::ID_BUTTON2 = wxNewId();
const long CamControlFrame::ID_BUTTON3 = wxNewId();
const long CamControlFrame::ID_BUTTON4 = wxNewId();
const long CamControlFrame::ID_BUTTON5 = wxNewId();
const long CamControlFrame::ID_BUTTON6 = wxNewId();
const long CamControlFrame::ID_STATICBITMAP1 = wxNewId();
const long CamControlFrame::ID_BUTTON7 = wxNewId();
const long CamControlFrame::ID_BUTTON8 = wxNewId();
const long CamControlFrame::ID_BUTTON9 = wxNewId();
const long CamControlFrame::ID_BUTTON10 = wxNewId();
const long CamControlFrame::ID_BUTTON11 = wxNewId();
const long CamControlFrame::ID_BUTTON12 = wxNewId();
const long CamControlFrame::ID_STATICTEXT1 = wxNewId();
const long CamControlFrame::ID_SLIDER1 = wxNewId();
const long CamControlFrame::ID_STATICTEXT2 = wxNewId();
const long CamControlFrame::ID_SLIDER2 = wxNewId();
const long CamControlFrame::ID_STATICTEXT8 = wxNewId();
const long CamControlFrame::ID_CHECKBOX1 = wxNewId();
const long CamControlFrame::ID_STATICTEXT3 = wxNewId();
const long CamControlFrame::ID_SLIDER3 = wxNewId();
const long CamControlFrame::ID_STATICTEXT4 = wxNewId();
const long CamControlFrame::ID_SLIDER4 = wxNewId();
const long CamControlFrame::ID_STATICTEXT9 = wxNewId();
const long CamControlFrame::ID_CHECKBOX2 = wxNewId();
const long CamControlFrame::ID_STATICTEXT5 = wxNewId();
const long CamControlFrame::ID_SLIDER5 = wxNewId();
const long CamControlFrame::ID_STATICTEXT6 = wxNewId();
const long CamControlFrame::ID_SLIDER6 = wxNewId();
const long CamControlFrame::ID_STATICTEXT10 = wxNewId();
const long CamControlFrame::ID_CHECKBOX3 = wxNewId();
const long CamControlFrame::ID_CHECKBOX4 = wxNewId();
const long CamControlFrame::ID_CHECKBOX5 = wxNewId();
const long CamControlFrame::ID_CHECKBOX6 = wxNewId();
const long CamControlFrame::ID_STATICTEXT7 = wxNewId();
const long CamControlFrame::idMenuQuit = wxNewId();
const long CamControlFrame::idMenuAbout = wxNewId();
const long CamControlFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(CamControlFrame,wxFrame)
    //(*EventTable(CamControlFrame)
    //*)
END_EVENT_TABLE()

CamControlFrame::CamControlFrame(wxWindow* parent,wxWindowID id)
{
    //setup v4l2 driver
    fd = open("/dev/video0",O_RDWR);
    v4l2_std_id std_id;
    std_id = V4L2_STD_PAL_BG;//

    if (-1 == ioctl (fd, VIDIOC_S_STD, &std_id))
    {
        perror ("VIDIOC_S_STD");
        exit (EXIT_FAILURE);
    }


    //(*Initialize(CamControlFrame)
    wxGridSizer* AdjCam_3;
    wxBoxSizer* BoxSizer4;
    wxStaticBoxSizer* StaticBoxSizer2;
    wxGridSizer* AdjCam_1;
    wxMenuItem* MenuItem2;
    wxStaticBoxSizer* StaticBoxSizer4;
    wxMenuItem* MenuItem1;
    wxBoxSizer* BoxSizer2;
    wxMenu* Menu1;
    wxGridSizer* AdjCam_2;
    wxStaticBoxSizer* StaticBoxSizer3;
    wxGridSizer* GridSizer1;
    wxBoxSizer* BoxSizer1;
    wxMenuBar* MenuBar1;
    wxStaticBoxSizer* StaticBoxSizer1;
    wxFlexGridSizer* FlexGridSizer1;
    wxBoxSizer* BoxSizer3;
    wxMenu* Menu2;
    wxStaticBoxSizer* StaticBoxSizer5;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(239,942));
    Move(wxPoint(1024,0));
    {
    	wxIcon FrameIcon;
    	FrameIcon.CopyFromBitmap(wxBitmap(wxImage(_T("/home/moincc/projekte/CamControl/multi.ico"))));
    	SetIcon(FrameIcon);
    }
    BoxSizer1 = new wxBoxSizer(wxVERTICAL);
    StaticBoxSizer1 = new wxStaticBoxSizer(wxHORIZONTAL, this, _("Programm"));
    Button2 = new wxButton(this, ID_BUTTON2, _("Exit"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));
    StaticBoxSizer1->Add(Button2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer1->Add(StaticBoxSizer1, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 0);
    BoxSizer2 = new wxBoxSizer(wxVERTICAL);
    FlexGridSizer1 = new wxFlexGridSizer(0, 2, 0, 0);
    BoxSizer3 = new wxBoxSizer(wxVERTICAL);
    All_Cams = new wxButton(this, ID_BUTTON3, _("All Cams"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON3"));
    BoxSizer3->Add(All_Cams, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Cams_1u2 = new wxButton(this, ID_BUTTON4, _("Cams. 1+2"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON4"));
    BoxSizer3->Add(Cams_1u2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Cams_1u3 = new wxButton(this, ID_BUTTON5, _("Cams. 1+3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON5"));
    BoxSizer3->Add(Cams_1u3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Cams_2u3 = new wxButton(this, ID_BUTTON6, _("Cams. 2+3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON6"));
    BoxSizer3->Add(Cams_2u3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    FlexGridSizer1->Add(BoxSizer3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
    StaticBitmap1 = new wxStaticBitmap(this, ID_STATICBITMAP1, wxBitmap(wxImage(_T("/home/moincc/projekte/CamControl/index.bmp"))), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICBITMAP1"));
    BoxSizer4->Add(StaticBitmap1, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    FlexGridSizer1->Add(BoxSizer4, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer2->Add(FlexGridSizer1, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 0);
    BoxSizer1->Add(BoxSizer2, 1, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 0);
    GridSizer1 = new wxGridSizer(0, 2, 0, 0);
    Full_Cam1 = new wxButton(this, ID_BUTTON7, _("Full Cam 1"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON7"));
    GridSizer1->Add(Full_Cam1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Full_Ov_1u2 = new wxButton(this, ID_BUTTON8, _("Full Ov. 1+2"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON8"));
    GridSizer1->Add(Full_Ov_1u2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Full_Cam2 = new wxButton(this, ID_BUTTON9, _("Full Cam 2"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON9"));
    GridSizer1->Add(Full_Cam2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Full_Ov_1u3 = new wxButton(this, ID_BUTTON10, _("Full Ov. 1+3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON10"));
    GridSizer1->Add(Full_Ov_1u3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Full_Cam3 = new wxButton(this, ID_BUTTON11, _("Full Cam 3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON11"));
    GridSizer1->Add(Full_Cam3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Full_Ov_2u3 = new wxButton(this, ID_BUTTON12, _("Full Ov. 2+3"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON12"));
    GridSizer1->Add(Full_Ov_2u3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer1->Add(GridSizer1, 0, wxALL|wxEXPAND|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 0);
    StaticBoxSizer2 = new wxStaticBoxSizer(wxVERTICAL, this, _("Bright (unfiltered)"));
    AdjCam_1 = new wxGridSizer(0, 2, 0, 0);
    StaticText1 = new wxStaticText(this, ID_STATICTEXT1, _("Brightness"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT1"));
    StaticText1->SetHelpText(_("Change Brightness"));
    AdjCam_1->Add(StaticText1, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Bright1 = new wxSlider(this, ID_SLIDER1, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER1"));
    AdjCam_1->Add(Bright1, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText2 = new wxStaticText(this, ID_STATICTEXT2, _("Contrast"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT2"));
    AdjCam_1->Add(StaticText2, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Contrast1 = new wxSlider(this, ID_SLIDER2, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER2"));
    AdjCam_1->Add(Contrast1, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText8 = new wxStaticText(this, ID_STATICTEXT8, _("Cross Markers"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT8"));
    AdjCam_1->Add(StaticText8, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Crosses1 = new wxCheckBox(this, ID_CHECKBOX1, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX1"));
    Crosses1->SetValue(false);
    AdjCam_1->Add(Crosses1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer2->Add(AdjCam_1, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    BoxSizer1->Add(StaticBoxSizer2, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer3 = new wxStaticBoxSizer(wxVERTICAL, this, _("pTurbo"));
    AdjCam_2 = new wxGridSizer(0, 2, 0, 0);
    StaticText3 = new wxStaticText(this, ID_STATICTEXT3, _("Brighness"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT3"));
    AdjCam_2->Add(StaticText3, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Bright2 = new wxSlider(this, ID_SLIDER3, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER3"));
    AdjCam_2->Add(Bright2, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText4 = new wxStaticText(this, ID_STATICTEXT4, _("Contrast"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT4"));
    AdjCam_2->Add(StaticText4, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Contrast2 = new wxSlider(this, ID_SLIDER4, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER4"));
    AdjCam_2->Add(Contrast2, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText9 = new wxStaticText(this, ID_STATICTEXT9, _("Cross Markers"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT9"));
    AdjCam_2->Add(StaticText9, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Crosses2 = new wxCheckBox(this, ID_CHECKBOX2, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX2"));
    Crosses2->SetValue(false);
    AdjCam_2->Add(Crosses2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer3->Add(AdjCam_2, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    BoxSizer1->Add(StaticBoxSizer3, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer4 = new wxStaticBoxSizer(wxVERTICAL, this, _("IR - Camera"));
    AdjCam_3 = new wxGridSizer(0, 2, 0, 0);
    StaticText5 = new wxStaticText(this, ID_STATICTEXT5, _("Brightness"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT5"));
    AdjCam_3->Add(StaticText5, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Bright3 = new wxSlider(this, ID_SLIDER5, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER5"));
    AdjCam_3->Add(Bright3, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText6 = new wxStaticText(this, ID_STATICTEXT6, _("Contrast"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT6"));
    AdjCam_3->Add(StaticText6, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Contrast3 = new wxSlider(this, ID_SLIDER6, 50, 0, 100, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_SLIDER6"));
    AdjCam_3->Add(Contrast3, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    StaticText10 = new wxStaticText(this, ID_STATICTEXT10, _("Cross Markers"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT10"));
    AdjCam_3->Add(StaticText10, 1, wxALL|wxALIGN_LEFT|wxALIGN_CENTER_VERTICAL, 5);
    Crosses3 = new wxCheckBox(this, ID_CHECKBOX3, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX3"));
    Crosses3->SetValue(false);
    AdjCam_3->Add(Crosses3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer4->Add(AdjCam_3, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 0);
    BoxSizer1->Add(StaticBoxSizer4, 0, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticBoxSizer5 = new wxStaticBoxSizer(wxHORIZONTAL, this, _("Magnification Calibration"));
    M4xBox = new wxCheckBox(this, ID_CHECKBOX4, _("4x"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX4"));
    M4xBox->SetValue(false);
    StaticBoxSizer5->Add(M4xBox, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    M8xBox = new wxCheckBox(this, ID_CHECKBOX5, _("8x"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX5"));
    M8xBox->SetValue(false);
    StaticBoxSizer5->Add(M8xBox, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    M16xBox = new wxCheckBox(this, ID_CHECKBOX6, _("16x"), wxDefaultPosition, wxDefaultSize, 0, wxDefaultValidator, _T("ID_CHECKBOX6"));
    M16xBox->SetValue(false);
    StaticBoxSizer5->Add(M16xBox, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer1->Add(StaticBoxSizer5, 0, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticText7 = new wxStaticText(this, ID_STATICTEXT7, _("Use <SPACE> on the  video-\nscreen for saving.\n\nBefore changing anything use \n<ESC> for stopping video.\n\nBefore pressing Exit use <ESC>\non videoscreen."), wxDefaultPosition, wxSize(200,20), 0, _T("ID_STATICTEXT7"));
    StaticText7->SetForegroundColour(wxColour(255,0,6));
    BoxSizer1->Add(StaticText7, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    SetSizer(BoxSizer1);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    BoxSizer1->SetSizeHints(this);

    Connect(ID_BUTTON2,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnButton2Click);
    Connect(ID_BUTTON3,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnButton3Click);
    Connect(ID_BUTTON4,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnButton4Click);
    Connect(ID_BUTTON5,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnButton5Click);
    Connect(ID_BUTTON6,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnButton6Click);
    Connect(ID_BUTTON7,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Cam_1_);
    Connect(ID_BUTTON8,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Ov_1u2_);
    Connect(ID_BUTTON9,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Cam_2_);
    Connect(ID_BUTTON10,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Ov_1u3_);
    Connect(ID_BUTTON11,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Cam_3_);
    Connect(ID_BUTTON12,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&CamControlFrame::Full_Ov_2u3_);
    Connect(ID_SLIDER1,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider1CmdScrollThumbTrack);
    Connect(ID_SLIDER1,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider1CmdScrollThumbRelease);
    Connect(ID_SLIDER2,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider2CmdScrollThumbTrack);
    Connect(ID_SLIDER2,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider2CmdScrollThumbRelease);
    Connect(ID_CHECKBOX1,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnCrosses1Click);
    Connect(ID_SLIDER3,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider3CmdScrollThumbTrack);
    Connect(ID_SLIDER3,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider3CmdScrollThumbRelease);
    Connect(ID_SLIDER4,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider4CmdScrollThumbTrack);
    Connect(ID_SLIDER4,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider4CmdScrollThumbRelease);
    Connect(ID_CHECKBOX2,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnCrosses2Click);
    Connect(ID_SLIDER5,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider5CmdScrollThumbTrack);
    Connect(ID_SLIDER5,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider5CmdScrollThumbRelease);
    Connect(ID_SLIDER6,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&CamControlFrame::OnSlider6CmdScrollThumbTrack);
    Connect(ID_SLIDER6,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&CamControlFrame::OnSlider6CmdScrollThumbRelease);
    Connect(ID_CHECKBOX3,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnCrosses3Click);
    Connect(ID_CHECKBOX4,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnM4xBoxClick);
    Connect(ID_CHECKBOX5,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnM8xBoxClick);
    Connect(ID_CHECKBOX6,wxEVT_COMMAND_CHECKBOX_CLICKED,(wxObjectEventFunction)&CamControlFrame::OnM16xBoxClick);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CamControlFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CamControlFrame::OnAbout);
    //*)


}

CamControlFrame::~CamControlFrame()
{
    //(*Destroy(CamControlFrame)
    //*)

}

void CamControlFrame::OnQuit(wxCommandEvent& event)
{
    cvDestroyAllWindows();
    Close();
}

void CamControlFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Camera aquisition"));
}

//Crosses for Overlay
void Crosses (Mat rahmen, int factor, int x, int y)
{
        //outer crosses
        line(rahmen,Point((95*factor)+x,(100*factor)+y),Point((105*factor)+x,(100*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((100*factor)+x,(95*factor)+y),Point((100*factor)+x,(105*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"A1",Point((105*factor)+x,(105*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((535*factor)+x,(100*factor)+y),Point((545*factor)+x,(100*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((540*factor)+x,(95*factor)+y),Point((540*factor)+x,(105*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"A2",Point((545*factor)+x,(105*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((95*factor)+x,(380*factor)+y),Point((105*factor)+x,(380*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((100*factor)+x,(375*factor)+y),Point((100*factor)+x,(385*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"A3",Point((105*factor)+x,(385*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((535*factor)+x,(380*factor)+y),Point((545*factor)+x,(380*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((540*factor)+x,(375*factor)+y),Point((540*factor)+x,(385*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"A4",Point((545*factor)+x,(385*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        //middle crosses
        line(rahmen,Point((145*factor)+x,(150*factor)+y),Point((155*factor)+x,(150*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((150*factor)+x,(145*factor)+y),Point((150*factor)+x,(155*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"B1",Point((155*factor)+x,(155*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((485*factor)+x,(150*factor)+y),Point((495*factor)+x,(150*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((490*factor)+x,(145*factor)+y),Point((490*factor)+x,(155*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"B2",Point((495*factor)+x,(155*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((145*factor)+x,(330*factor)+y),Point((155*factor)+x,(330*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((150*factor)+x,(325*factor)+y),Point((150*factor)+x,(335*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"B3",Point((155*factor)+x,(335*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((485*factor)+x,(330*factor)+y),Point((495*factor)+x,(330*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((490*factor)+x,(325*factor)+y),Point((490*factor)+x,(335*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"B4",Point((495*factor)+x,(335*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        //inner crosses
        line(rahmen,Point((195*factor)+x,(280*factor)+y),Point((205*factor)+x,(280*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((200*factor)+x,(275*factor)+y),Point((200*factor)+x,(285*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"C1",Point((205*factor)+x,(285*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((195*factor)+x,(200*factor)+y),Point((205*factor)+x,(200*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((200*factor)+x,(195*factor)+y),Point((200*factor)+x,(205*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"C2",Point((205*factor)+x,(205*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((435*factor)+x,(280*factor)+y),Point((445*factor)+x,(280*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((440*factor)+x,(275*factor)+y),Point((440*factor)+x,(285*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"C3",Point((445*factor)+x,(285*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        line(rahmen,Point((435*factor)+x,(200*factor)+y),Point((445*factor)+x,(200*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((440*factor)+x,(195*factor)+y),Point((440*factor)+x,(205*factor)+y),CV_RGB(255,0,0),0,8,0);
        putText(rahmen,"C4",Point((445*factor)+x,(205*factor)+y),FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0,0,255),1,8);

        //center
        line(rahmen,Point((310*factor)+x,(240*factor)+y),Point((330*factor)+x,(240*factor)+y),CV_RGB(255,0,0),0,8,0);
        line(rahmen,Point((320*factor)+x,(230*factor)+y),Point((320*factor)+x,(250*factor)+y),CV_RGB(255,0,0),0,8,0);
}

void calibration (Mat rahmen, int x, int y, int factor, string vertical, string horizontal)
{
    putText(rahmen,vertical,Point(30+x,10+y),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
    putText(rahmen,horizontal,Point(30+x,20+y),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);

    //crossbar
    line(rahmen,Point((20*factor)+x,(10*factor)+y),Point((20*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((20*factor)+x,(460*factor)+y),Point((630*factor)+x,(460*factor)+y),CV_RGB(255,0,0),0,8,0);

    //vertical
    line(rahmen,Point((15*factor)+x,(10*factor)+y),Point((25*factor)+x,(10*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(60*factor)+y),Point((25*factor)+x,(60*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(110*factor)+y),Point((25*factor)+x,(110*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(160*factor)+y),Point((25*factor)+x,(160*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(210*factor)+y),Point((25*factor)+x,(210*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(260*factor)+y),Point((25*factor)+x,(260*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(310*factor)+y),Point((25*factor)+x,(310*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(360*factor)+y),Point((25*factor)+x,(360*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(410*factor)+y),Point((25*factor)+x,(410*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((15*factor)+x,(460*factor)+y),Point((25*factor)+x,(460*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((70*factor)+x,(455*factor)+y),Point((70*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);

    //horizontal
    line(rahmen,Point((130*factor)+x,(455*factor)+y),Point((130*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((180*factor)+x,(455*factor)+y),Point((180*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((230*factor)+x,(455*factor)+y),Point((230*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((280*factor)+x,(455*factor)+y),Point((280*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((330*factor)+x,(455*factor)+y),Point((330*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((380*factor)+x,(455*factor)+y),Point((380*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((430*factor)+x,(455*factor)+y),Point((430*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((480*factor)+x,(455*factor)+y),Point((480*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((530*factor)+x,(455*factor)+y),Point((530*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((580*factor)+x,(455*factor)+y),Point((580*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
    line(rahmen,Point((630*factor)+x,(455*factor)+y),Point((630*factor)+x,(465*factor)+y),CV_RGB(255,0,0),0,8,0);
}

void signature (Mat rahmen, int screensize)
{
    if (screensize==1)
    {
        putText(rahmen,"Dr.rer.nat. A. Rohwedder",Point(1,950),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
        putText(rahmen,"Dr.rer.nat. A. Rohwedder",Point(641,950),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
        putText(rahmen,"Dr.rer.nat. A. Rohwedder",Point(1,470),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
        putText(rahmen,"Dr.rer.nat. A. Rohwedder",Point(641,470),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
    }
    if (screensize==2)
    {
        putText(rahmen,"Dr.rer.nat. A. Rohwedder",Point(1,950),FONT_HERSHEY_SIMPLEX, 0.4, Scalar(0,0,255),1,8);
    }
}
//save function
void saveas(Mat rahmen, string anhang)
{
    //variables
    time_t seconds;
    string fullname;
    string zwischen;
    seconds = time (NULL);

    //get time
    time (&seconds);
    stringstream ss1;
    ss1<<seconds;

    //int to string
    ss1 >> zwischen;

    //combine time + filetype
    fullname= zwischen + anhang;

    //string to char
    char *timechar=new char[fullname.size()+10];
    timechar[fullname.size()]=0;
    memcpy(timechar,fullname.c_str(),fullname.size());

    imwrite (timechar, rahmen);

    //clean up
    rahmen.release();
    delete timechar;
    anhang = "";
    ss1.str("");
    timechar = 0;
    seconds = 0;

}


//Exit Programm
void CamControlFrame::OnButton2Click(wxCommandEvent& event)
{
    cvDestroyAllWindows();
    Close();
}

void aquire (int ntimes, VideoCapture streamer, double adbright, double adcont, int indi)
{

    streamer.set(CV_CAP_PROP_BRIGHTNESS,(adbright/100));
    streamer.set(CV_CAP_PROP_CONTRAST,(adcont/100));

    if (-1 == ioctl (fd, VIDIOC_S_INPUT, &indi))
    {
        perror ("VIDIOC_S_INPUT");
        exit (EXIT_FAILURE);
    }

    for (int i = 1; i<ntimes; i++)
    {

        streamer >> singlescreen;
    }

}

void calchoice (Mat rahmen2, int screensize)
{
    if (screensize==1){
        if (M4boxbutton == true)
        {
            calibration(rahmen2,0,0,1,"H: one line = 2.6 mm", "V: one line = 2.7 mm");
            calibration(rahmen2,640,0,1,"H: one line = 2.6 mm", "V: one line = 2.7 mm");
            calibration(rahmen2,0,480,1,"H: one line = 2.6 mm", "V: one line = 2.7 mm");
        }

        if (M8boxbutton == true)
        {
            calibration(rahmen2,0,0,1,"H: one line = 1.3 mm", "V: one line = 1.4 mm");
            calibration(rahmen2,640,0,1,"H: one line = 1.3 mm", "V: one line = 1.4 mm");
            calibration(rahmen2,0,480,1,"H: one line = 1.3 mm", "V: one line = 1.4 mm");
        }

        if (M16boxbutton == true)
        {
            calibration(rahmen2,0,0,1,"H: one line = 0.68 mm", "V: one line = 0.69 mm");
            calibration(rahmen2,640,0,1,"H: one line = 0.68 mm", "V: one line = 0.69 mm");
            calibration(rahmen2,0,480,1,"H: one line = 0.68 mm", "V: one line = 0.69 mm");
        }
    }
    if (screensize==2){
        if (M4boxbutton == true)
        {
            calibration(rahmen2,0,0,2,"H: one line = 2.6 mm", "V: one line = 2.8 mm");
        }

        if (M8boxbutton == true)
        {
            calibration(rahmen2,0,0,2,"H: one line = 1.3 mm", "V: one line = 1.3 mm");
        }

        if (M16boxbutton == true)
        {
            calibration(rahmen2,0,0,2,"H: one line = 0.68 mm", "V: one line = 0.7 mm");
        }
    }
}

// All Cams + Overlay all
void CamControlFrame::OnButton3Click(wxCommandEvent& event)
{

    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras",CV_WINDOW_AUTOSIZE);
    fullscreen = imread("/home/moincc/projekte/CamControl3/bin/Debug/001b.jpg");

    //display video
    while(key != 27)
    {
        key=waitKey(10);

        aquire(5,stream1,bright01,contrast01,0);

        singlescreen.copyTo(fullscreen(Rect(640,0,640,480)));
        singlescreen.copyTo(fullscreen(Rect(640,480,640,480)));

        aquire(5,stream1,bright02,contrast02,1);

        singlescreen.copyTo(fullscreen(Rect(0,480,640,480)));

        //overlay pTurbo
        int xshift = 0;
        int yshift = 0;
        if (M4boxbutton == true)
        {
            xshift = 27;
            yshift = 18;
        }
        if (M8boxbutton == true)
        {
            xshift = 29;
            yshift = 18;
        }
        if (M16boxbutton == true)
        {
            xshift = -1;
            yshift = 15;
        }

        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[2]+bgrPixel.val[1]+bgrPixel.val[0];
                if (pixval> 150){line(fullscreen,Point((640+i-xshift),(480+j-yshift)),Point((640+i-xshift),(480+j-yshift)),CV_RGB(255,0,0),0,8,0);}
            }
        }

        aquire(5,stream1,bright03,contrast03,2);

        singlescreen.copyTo(fullscreen(Rect(0,0,640,480)));

        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[2]+bgrPixel.val[1]+bgrPixel.val[0];
                if (pixval> 150){line(fullscreen,Point((640+i),(480+j)),Point((640+i),(480+j)),CV_RGB(0,255,0),0,8,0);}
            }
        }

        signature(fullscreen,1);

        cvMoveWindow("Cameras",1280,0);

        //add markers
        if (crossesbutton3 == true){ Crosses(fullscreen,1,0,0);}
        if (crossesbutton1 == true){ Crosses(fullscreen,1,640,0);}
        if (crossesbutton2 == true){ Crosses(fullscreen,1,0,480);}

        calchoice(fullscreen,1);

        imshow("Cameras",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_AllCam.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

//Cams 1 and 2 + Overlay
void CamControlFrame::OnButton4Click(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 1 and 2",CV_WINDOW_AUTOSIZE);
    fullscreen = imread("/home/moincc/projekte/CamControl3/bin/Debug/001b.jpg");

    //display video
    while(key != 27)
    {
        key=waitKey(10);
        //stream to frames
        aquire(6,stream1,bright01,contrast01,0);

        singlescreen.copyTo(fullscreen(Rect(0,0,640,480)));
        singlescreen.copyTo(fullscreen(Rect(640,480,640,480)));

        aquire(4,stream1,bright02,contrast02,1);

        singlescreen.copyTo(fullscreen(Rect(640,0,640,480)));

        //produce overlay
        int xshift = 0;
        int yshift = 0;
        if (M4boxbutton == true)
        {
            xshift = 0;
            yshift = 0;
        }
        if (M8boxbutton == true)
        {
            xshift = 0;
            yshift = 0;
        }
        if (M16boxbutton == true)
        {
            xshift = 0;
            yshift = 0;
        }

        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[2]+bgrPixel.val[1]+bgrPixel.val[0];
                if (pixval> 150){line(fullscreen,Point((640+i-xshift),(480+j-yshift)),Point((640+i-xshift),(480+j-yshift)),CV_RGB(255,0,0),0,8,0);}
                if (pixval> 350){line(fullscreen,Point((640+i-xshift),(480+j-yshift)),Point((640+i-xshift),(480+j-yshift)),CV_RGB(255,255,255),0,8,0);}
            }
        }

        signature(fullscreen,1);

        cvMoveWindow("Cameras 1 and 2",1280,0);

        //add markers
        if (crossesbutton1 == true){ Crosses(fullscreen,1,0,0);}
        if (crossesbutton2 == true){ Crosses(fullscreen,1,640,0);}

        calchoice(fullscreen,1);

        imshow("Cameras 1 and 2",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov1u2.BMP");
        }
    }
    //clean up
    fullscreen.release();
    stream1.release();
}

//Cams 1 and 3 + Overlay
void CamControlFrame::OnButton5Click(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 1 and 3",CV_WINDOW_AUTOSIZE);
    fullscreen = imread("/home/moincc/projekte/CamControl3/bin/Debug/001b.jpg");

    //display video
    while(key != 27)
    {
        key=waitKey(10);
        //streams to frames
        aquire(6,stream1,bright01,contrast01,0);

        singlescreen.copyTo(fullscreen(Rect(0,0,640,480)));
        singlescreen.copyTo(fullscreen(Rect(640,480,640,480)));

        aquire(4,stream1,bright03,contrast03,2);

        singlescreen.copyTo(fullscreen(Rect(640,0,640,480)));

        //produce overlay

        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[0]+ bgrPixel.val[1] + bgrPixel.val[2];
                if (pixval> 150){line(fullscreen,Point((640+i),(480+j)),Point((640+i),(480+j)),CV_RGB(0,255,0),0,8,0);}
                if (pixval> 350){line(fullscreen,Point((640+i),(480+j)),Point((640+i),(480+j)),CV_RGB(255,255,255),0,8,0);}
            }
        }

        cvMoveWindow("Cameras 1 and 3",1280,0);

        //add markers
        if (crossesbutton1 == true){ Crosses(fullscreen,1,0,0);}
        if (crossesbutton3 == true){ Crosses(fullscreen,1,640,0);}

        calchoice(fullscreen,1);

        signature(fullscreen,1);

        imshow("Cameras 1 and 3",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov1u3.BMP");
        }
    }
    //clean up
    fullscreen.release();
    stream1.release();
}

//Cams 2 and 3 + Overlay
void CamControlFrame::OnButton6Click(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 2 and 3",CV_WINDOW_AUTOSIZE);
    fullscreen = imread("/home/moincc/projekte/CamControl3/bin/Debug/001b.jpg");

    //display video
    while(key != 27)
    {
        key=waitKey(10);

        //streams to frames
        aquire(5,stream1,bright02,contrast02,1);
        singlescreen.copyTo(fullscreen(Rect(0,480,640,480)));
        addWeighted(singlescreen,0.5,singlescreen,0.5,0.0,Overlaysmall);

        aquire(4,stream1,bright03,contrast03,2);
        singlescreen.copyTo(fullscreen(Rect(0,0,640,480)));
        addWeighted(Overlaysmall,0.5,singlescreen,0.5,0.0,Overlaysmall2);

        Overlaysmall2.copyTo(fullscreen(Rect(640,480,640,480)));

        cvMoveWindow("Cameras 2 and 3",1280,0);

        signature(fullscreen,1);

        //add markers

        if (crossesbutton2 == true){ Crosses(fullscreen,1,0,0);}
        if (crossesbutton3 == true){ Crosses(fullscreen,1,0,480);}

        calchoice(fullscreen,1);

        imshow("Cameras 2 and 3",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov2u3.BMP");
        }
    }
    //clean up
    fullscreen.release();
    stream1.release();
}

//Cam 1 resizable
void CamControlFrame::Full_Cam_1_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign device
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Bright (unfiltered)",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(20);
        //stream to frame
        aquire(2,stream1,bright01,contrast01,0);

        resize(singlescreen,fullscreen,Size(1280,960),2,2);

        signature(fullscreen,2);

        cvMoveWindow("Bright (unfiltered)",1280,0);

        if (crossesbutton1 == true){ Crosses(fullscreen,2,0,0);}

        calchoice(fullscreen,2);

        imshow("Bright (unfiltered)",fullscreen);
        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Cam1.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

//Cams 1 and 2 Overlay resizable
void CamControlFrame::Full_Ov_1u2_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 1 and 2",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(10);
        //stream to frames
        aquire(6,stream1,bright01,contrast01,0);

        resize(singlescreen,fullscreen,Size(1280,960),2,2);

        aquire(4,stream1,bright02,contrast02,1);

        int xshift = 0;
        int yshift = 0;
        if (M4boxbutton == true)
        {
            xshift = 27;
            yshift = 18;
        }
        if (M8boxbutton == true)
        {
            xshift = 29;
            yshift = 18;
        }
        if (M16boxbutton == true)
        {
            xshift = -1;
            yshift = 15;
        }

        //produce overlay
        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[2]+bgrPixel.val[1]+bgrPixel.val[0];
                if (pixval> 150){line(fullscreen,Point(((i-xshift)*2),((j-yshift)*2)),Point(((i-xshift)*2)+1,((j-yshift)*2)+1),CV_RGB(255,0,0),1,8,0);}
                if (pixval> 350){line(fullscreen,Point(((i-xshift)*2),((j-yshift)*2)),Point(((i-xshift)*2)+1,((j-yshift)*2)+1),CV_RGB(255,255,255),1,8,0);}
            }
        }

        cvMoveWindow("Cameras 1 and 2",1280,0);

        signature(fullscreen,2);

        if (crossesbutton1 == true){ Crosses(fullscreen,2,0,0);}

        calchoice(fullscreen,2);

        imshow("Cameras 1 and 2",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov1u2.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

// Cam 2 resizable
void CamControlFrame::Full_Cam_2_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign device
    VideoCapture stream1(0);

    //generate frame
    namedWindow("pTurbo",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(20);

        //stream to frames
        aquire(2,stream1,bright02,contrast02,1);

        resize(singlescreen,fullscreen,Size(1280,960),2,2);

        if (crossesbutton2 == true){ Crosses(fullscreen,2,0,0);}
        cvMoveWindow("pTurbo",1280,0);

        signature(fullscreen,2);

        calchoice(fullscreen,2);

        imshow("pTurbo",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Cam2.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

// Cams 1 and 3 Overlay resizable
void CamControlFrame::Full_Ov_1u3_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 1 and 3",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(10);
        //stream to frames
        aquire(6,stream1,bright01,contrast01,0);

        resize(singlescreen,fullscreen,Size(1280,960),2,2);

        aquire(4,stream1,bright03,contrast03,2);

        //produce overlay
        for (int i = 0; i<640; i++)
        {
            for (int j = 0; j<480; j++)
            {
                Vec3b bgrPixel = singlescreen.at<Vec3b>(j,i);
                pixval = bgrPixel.val[2]+bgrPixel.val[1]+bgrPixel.val[0];
                if (pixval> 150){line(fullscreen,Point((i*2),(j*2)),Point((i*2)+1,(j*2)+1),CV_RGB(0,255,0),1,8,0);}
                if (pixval> 350){line(fullscreen,Point((i*2),(j*2)),Point((i*2)+1,(j*2)+1),CV_RGB(255,255,255),1,8,0);}
            }
        }

        cvMoveWindow("Cameras 1 and 3",1280,0);

        signature(fullscreen,2);

        if (crossesbutton1 == true){ Crosses(fullscreen,2,0,0);}

        calchoice(fullscreen,2);

        imshow("Cameras 1 and 3",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov1u3.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

// Cam 3 resizable
void CamControlFrame::Full_Cam_3_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign device
    VideoCapture stream1(0);

    //generate frame
    namedWindow("IR-Camera",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(20);

        //stream to frames
        aquire(2,stream1,bright03,contrast03,2);

        resize(singlescreen,fullscreen,Size(1280,960),2,2);
        cvMoveWindow("IR-Camera",1280,0);

        signature(fullscreen,2);

        if (crossesbutton3 == true){ Crosses(fullscreen,2,0,0);}

        calchoice(fullscreen,2);

        imshow("IR-Camera",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Cam3.BMP");
        }
    }
    //clean up
    stream1.release();
    fullscreen.release();
}

// Cams 2 and 3 Overlay resizable
void CamControlFrame::Full_Ov_2u3_(wxCommandEvent& event)
{
    cvDestroyAllWindows();

    key = 0;

    //assign devices
    VideoCapture stream1(0);

    //generate frame
    namedWindow("Cameras 2 and 3",CV_WINDOW_AUTOSIZE);

    //display video
    while(key != 27)
    {
        key=waitKey(10);

        aquire(5,stream1,bright02,contrast02,1);

        addWeighted(singlescreen,0.5,singlescreen,0.5,0.0,Overlaysmall);

        aquire(5,stream1,bright03,contrast03,2);

        addWeighted(Overlaysmall,0.5,singlescreen,0.5,0.0,Overlaysmall2);
        resize(Overlaysmall2,fullscreen,Size(1280,960),2,2);
        cvMoveWindow("Cameras 2 and 3",1280,0);

        signature(fullscreen,2);

        if (crossesbutton2 == true){ Crosses(fullscreen,2,0,0);}

        calchoice(fullscreen,2);

        imshow("Cameras 2 and 3",fullscreen);

        //save frame as .bmp
        if(key == 32)
        {
            saveas(fullscreen,"_Ov2u3.BMP");
        }
    }
    //clean up
    fullscreen.release();
    stream1.release();

}

// Slider Brightness Cam 1
void CamControlFrame::OnSlider1CmdScrollThumbTrack(wxScrollEvent& event)
{
    bright01 = Bright1->GetValue();
}

void CamControlFrame::OnSlider1CmdScrollThumbRelease(wxScrollEvent& event)
{
    bright01 = Bright1->GetValue();
}

// Slider Contrast Cam 1
void CamControlFrame::OnSlider2CmdScrollThumbTrack(wxScrollEvent& event)
{
    contrast01 = Contrast1->GetValue();
}

void CamControlFrame::OnSlider2CmdScrollThumbRelease(wxScrollEvent& event)
{
    contrast01 = Contrast1->GetValue();
}

// Slider Brightness Cam 2
void CamControlFrame::OnSlider3CmdScrollThumbTrack(wxScrollEvent& event)
{
    bright02 = Bright2->GetValue();
}

void CamControlFrame::OnSlider3CmdScrollThumbRelease(wxScrollEvent& event)
{
    bright02 = Bright2->GetValue();
}

// Slider Contrast Cam 2
void CamControlFrame::OnSlider4CmdScrollThumbTrack(wxScrollEvent& event)
{
    contrast02 = Contrast2->GetValue();
}

void CamControlFrame::OnSlider4CmdScrollThumbRelease(wxScrollEvent& event)
{
    contrast02 = Contrast2->GetValue();
}

// Slider Brighness Cam 3
void CamControlFrame::OnSlider5CmdScrollThumbTrack(wxScrollEvent& event)
{
    bright03 = Bright3->GetValue();
}

void CamControlFrame::OnSlider5CmdScrollThumbRelease(wxScrollEvent& event)
{
    bright03 = Bright3->GetValue();
}

// Slider Contrast Cam 3
void CamControlFrame::OnSlider6CmdScrollThumbTrack(wxScrollEvent& event)
{
    contrast03 = Contrast3->GetValue();
}

void CamControlFrame::OnSlider6CmdScrollThumbRelease(wxScrollEvent& event)
{
    contrast03 = Contrast3->GetValue();
}

// Crosses checkers
void CamControlFrame::OnCrosses1Click(wxCommandEvent& event)
{
    crossesbutton1 = Crosses1->GetValue();
}

void CamControlFrame::OnCrosses2Click(wxCommandEvent& event)
{
    crossesbutton2 = Crosses2->GetValue();
}

void CamControlFrame::OnCrosses3Click(wxCommandEvent& event)
{
    crossesbutton3 = Crosses3->GetValue();
}

void CamControlFrame::OnM4xBoxClick(wxCommandEvent& event)
{
    M4boxbutton = M4xBox->GetValue();
}

void CamControlFrame::OnM8xBoxClick(wxCommandEvent& event)
{
    M8boxbutton = M8xBox->GetValue();
}

void CamControlFrame::OnM16xBoxClick(wxCommandEvent& event)
{
    M16boxbutton = M16xBox->GetValue();
}
