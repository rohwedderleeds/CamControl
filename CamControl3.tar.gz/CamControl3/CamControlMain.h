/***************************************************************
 * Name:      CamControlMain.h
 * Purpose:   Defines Application Frame
 * Author:    Arndt Rohwedder (arndt.rohwedder@rad.uni-kiel.de)
 * Created:   2013-04-23
 * Copyright: Arndt Rohwedder ()
 * License:
 **************************************************************/

#ifndef CAMCONTROLMAIN_H
#define CAMCONTROLMAIN_H

//(*Headers(CamControlFrame)
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/menu.h>
#include <wx/checkbox.h>
#include <wx/slider.h>
#include <wx/statbmp.h>
#include <wx/button.h>
#include <wx/frame.h>
#include <wx/statusbr.h>
//*)

class CamControlFrame: public wxFrame
{
    public:

        CamControlFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~CamControlFrame();

    private:

        //(*Handlers(CamControlFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnSlider2CmdScroll(wxScrollEvent& event);
        void OnButton2Click(wxCommandEvent& event);
        void OnButton3Click(wxCommandEvent& event);
        void OnSlider1CmdScrollThumbTrack(wxScrollEvent& event);
        void OnSlider2CmdScrollThumbTrack(wxScrollEvent& event);
        void OnSlider3CmdScrollThumbTrack(wxScrollEvent& event);
        void OnSlider4CmdScrollThumbTrack(wxScrollEvent& event);
        void OnSlider5CmdScrollThumbTrack(wxScrollEvent& event);
        void OnSlider6CmdScrollThumbTrack(wxScrollEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        void OnSlider1CmdScrollThumbRelease(wxScrollEvent& event);
        void OnSlider2CmdScrollThumbRelease(wxScrollEvent& event);
        void OnButton4Click(wxCommandEvent& event);
        void OnButton5Click(wxCommandEvent& event);
        void OnButton6Click(wxCommandEvent& event);
        void Full_Cam_1_(wxCommandEvent& event);
        void Full_Cam_2_(wxCommandEvent& event);
        void Full_Cam_3_(wxCommandEvent& event);
        void OnSlider3CmdScrollThumbRelease(wxScrollEvent& event);
        void OnSlider4CmdScrollThumbRelease(wxScrollEvent& event);
        void OnSlider5CmdScrollThumbRelease(wxScrollEvent& event);
        void OnSlider6CmdScrollThumbRelease(wxScrollEvent& event);
        void Full_Ov_1u2_(wxCommandEvent& event);
        void Full_Ov_1u3_(wxCommandEvent& event);
        void Full_Ov_2u3_(wxCommandEvent& event);
        void OnCrosses1Click(wxCommandEvent& event);
        void OnCrosses2Click(wxCommandEvent& event);
        void OnCrosses3Click(wxCommandEvent& event);
        void OnM4xBoxClick(wxCommandEvent& event);
        void OnM8xBoxClick(wxCommandEvent& event);
        void OnM16xBoxClick(wxCommandEvent& event);
        //*)

        //(*Identifiers(CamControlFrame)
        static const long ID_BUTTON2;
        static const long ID_BUTTON3;
        static const long ID_BUTTON4;
        static const long ID_BUTTON5;
        static const long ID_BUTTON6;
        static const long ID_STATICBITMAP1;
        static const long ID_BUTTON7;
        static const long ID_BUTTON8;
        static const long ID_BUTTON9;
        static const long ID_BUTTON10;
        static const long ID_BUTTON11;
        static const long ID_BUTTON12;
        static const long ID_STATICTEXT1;
        static const long ID_SLIDER1;
        static const long ID_STATICTEXT2;
        static const long ID_SLIDER2;
        static const long ID_STATICTEXT8;
        static const long ID_CHECKBOX1;
        static const long ID_STATICTEXT3;
        static const long ID_SLIDER3;
        static const long ID_STATICTEXT4;
        static const long ID_SLIDER4;
        static const long ID_STATICTEXT9;
        static const long ID_CHECKBOX2;
        static const long ID_STATICTEXT5;
        static const long ID_SLIDER5;
        static const long ID_STATICTEXT6;
        static const long ID_SLIDER6;
        static const long ID_STATICTEXT10;
        static const long ID_CHECKBOX3;
        static const long ID_CHECKBOX4;
        static const long ID_CHECKBOX5;
        static const long ID_CHECKBOX6;
        static const long ID_STATICTEXT7;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(CamControlFrame)
        wxStaticText* StaticText10;
        wxStaticText* StaticText9;
        wxCheckBox* M4xBox;
        wxButton* Full_Cam3;
        wxButton* Full_Ov_1u3;
        wxSlider* Contrast2;
        wxStaticText* StaticText2;
        wxButton* Cams_2u3;
        wxCheckBox* M16xBox;
        wxStaticText* StaticText6;
        wxStaticBitmap* StaticBitmap1;
        wxButton* Full_Ov_2u3;
        wxButton* Full_Cam1;
        wxStaticText* StaticText8;
        wxCheckBox* Crosses1;
        wxStaticText* StaticText1;
        wxSlider* Bright1;
        wxStaticText* StaticText3;
        wxSlider* Contrast3;
        wxButton* Button2;
        wxCheckBox* Crosses2;
        wxButton* All_Cams;
        wxSlider* Contrast1;
        wxStaticText* StaticText5;
        wxStaticText* StaticText7;
        wxStatusBar* StatusBar1;
        wxButton* Full_Cam2;
        wxCheckBox* Crosses3;
        wxButton* Cams_1u3;
        wxCheckBox* M8xBox;
        wxButton* Full_Ov_1u2;
        wxSlider* Bright3;
        wxStaticText* StaticText4;
        wxButton* Cams_1u2;
        wxSlider* Bright2;
        //*)

        DECLARE_EVENT_TABLE()
};


#endif // CAMCONTROLMAIN_H
