/***************************************************************
 * Name:      CamControlApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Arndt Rohwedder (arndt.rohwedder@rad.uni-kiel.de)
 * Created:   2013-04-23
 * Copyright: Arndt Rohwedder ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "CamControlApp.h"

//(*AppHeaders
#include "CamControlMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(CamControlApp);

bool CamControlApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	CamControlFrame* Frame = new CamControlFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
